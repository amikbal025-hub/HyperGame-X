package com.hypergamex.app

import android.app.Activity
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MiniGameActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var score by remember { mutableIntStateOf(0) }
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF8B7CFF), background = Color(0xFF090B12))) {
                Column(
                    Modifier.fillMaxSize().background(Color(0xFF090B12)).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("TAP RUSH", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Mini game bawaan hyperGame X", color = Color.LightGray)
                    Spacer(Modifier.height(32.dp))
                    Text("$score", style = MaterialTheme.typography.displayLarge, color = Color.White)
                    Spacer(Modifier.height(20.dp))
                    Surface(
                        modifier = Modifier.size(180.dp).clickable { score++ },
                        shape = RoundedCornerShape(36.dp),
                        color = Color(0xFF5146B8)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("TAP!", style = MaterialTheme.typography.headlineLarge, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    OutlinedButton(onClick = { score = 0 }) { Text("Reset") }
                }
            }
        }
    }
}
