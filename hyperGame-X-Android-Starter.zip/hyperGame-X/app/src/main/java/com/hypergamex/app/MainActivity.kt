package com.hypergamex.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import rikka.shizuku.Shizuku

private val Bg = Color(0xFF090B12)
private val Panel = Color(0xFF151925)
private val Accent = Color(0xFF8B7CFF)
private val Muted = Color(0xFF9AA3B7)

class MainActivity : ComponentActivity() {
    private var shizukuStatus by mutableStateOf("Memeriksa Shizuku…")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refreshShizuku()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Bg, surface = Panel, primary = Accent,
                    onBackground = Color.White, onSurface = Color.White
                )
            ) {
                HyperGameHome(
                    shizukuStatus = shizukuStatus,
                    onOverlay = { openFloatingWindow() },
                    onShizuku = { requestShizuku() },
                    onRefresh = { refreshShizuku() },
                    onMiniGame = { startActivity(Intent(this, MiniGameActivity::class.java)) },
                    onApps = { openAppPicker() }
                )
            }
        }
    }

    private fun refreshShizuku() {
        shizukuStatus = try {
            when {
                !Shizuku.pingBinder() -> "Shizuku belum aktif"
                Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED ->
                    "Terhubung • izin diberikan"
                else -> "Server aktif • izin belum diberikan"
            }
        } catch (_: Exception) {
            "Shizuku belum terdeteksi"
        }
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                shizukuStatus = "Aktifkan layanan Shizuku terlebih dahulu"
            } else if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(1001)
                shizukuStatus = "Permintaan izin dikirim"
            } else {
                shizukuStatus = "Terhubung • izin diberikan"
            }
        } catch (_: Exception) {
            shizukuStatus = "Shizuku tidak tersedia"
        }
    }

    private fun openFloatingWindow() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }
        startService(Intent(this, FloatingWindowService::class.java))
    }

    private fun openAppPicker() {
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launchIntent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        val labels = apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        val intents = apps.map {
            packageManager.getLaunchIntentForPackage(it.activityInfo.packageName)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Pilih aplikasi")
            .setItems(labels) { _, which ->
                intents.getOrNull(which)?.let { startActivity(it) }
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}

@Composable
private fun HyperGameHome(
    shizukuStatus: String,
    onOverlay: () -> Unit,
    onShizuku: () -> Unit,
    onRefresh: () -> Unit,
    onMiniGame: () -> Unit,
    onApps: () -> Unit
) {
    var tab by remember { mutableStateOf("Home") }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home", "Game Space", "Floating", "Settings").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {
                            Icon(
                                when (item) {
                                    "Game Space" -> Icons.Default.SportsEsports
                                    "Floating" -> Icons.Default.PictureInPictureAlt
                                    "Settings" -> Icons.Default.Settings
                                    else -> Icons.Default.Home
                                }, contentDescription = item
                            )
                        },
                        label = { Text(item) }
                    )
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("hyperGame X", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("PLAY MORE. DO MORE.", color = Muted, style = MaterialTheme.typography.labelMedium)
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("GAME CONTROL CENTER", color = Accent, style = MaterialTheme.typography.labelMedium)
                        Text("Semua aktivitas gaming, satu tempat.", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text("Kelola game, buka mini game, dan aktifkan floating window.", color = Muted)
                    }
                }
            }
            item {
                Text("Quick actions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ActionCard("Floating Window", "Jendela di atas aplikasi", Icons.Default.OpenInNew, onOverlay, Modifier.weight(1f))
                    ActionCard("Mini Game", "Game bawaan", Icons.Default.Bolt, onMiniGame, Modifier.weight(1f))
                }
            }
            item {
                ActionCard("Buka aplikasi", "Pilih aplikasi terpasang untuk dijalankan", Icons.Default.Apps, onApps, Modifier.fillMaxWidth())
            }
            item {
                Text("Advanced system", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Extension, contentDescription = null, tint = Accent)
                            Spacer(Modifier.width(8.dp))
                            Text("Shizuku Bridge", fontWeight = FontWeight.SemiBold)
                        }
                        Text(shizukuStatus, color = Muted)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = onRefresh) { Text("Periksa") }
                            Button(onClick = onShizuku) { Text("Hubungkan") }
                        }
                        Text("Shizuku bersifat opsional. Fitur lanjutan hanya aktif jika didukung perangkat.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Text("Catatan: Floating Window versi awal adalah panel interaktif milik hyperGame X. Menjalankan aplikasi lain sebagai freeform window bergantung pada dukungan firmware Android.", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ActionCard(
    title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit, modifier: Modifier = Modifier
) {
    Card(modifier = modifier.clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = Accent)
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}
