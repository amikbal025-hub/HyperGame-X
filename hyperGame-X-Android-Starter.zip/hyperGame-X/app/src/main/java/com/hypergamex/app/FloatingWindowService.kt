package com.hypergamex.app

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color as AndroidColor

class FloatingWindowService : Service() {
    private lateinit var windowManager: WindowManager
    private var window: View? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (window == null) showWindow()
        return START_NOT_STICKY
    }

    private fun showWindow() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(AndroidColor.rgb(20, 24, 36))
            setPadding(18, 12, 18, 18)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 4, 4, 12)
        }
        val title = TextView(this).apply {
            text = "hyperGame X  •  Floating"
            textSize = 14f
            setTextColor(AndroidColor.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val minimize = Button(this).apply { text = "—"; setOnClickListener { stopSelf() } }
        val close = Button(this).apply { text = "×"; setOnClickListener { stopSelf() } }
        header.addView(title)
        header.addView(minimize)
        header.addView(close)
        header.setOnTouchListener(DragTouchListener())

        val body = TextView(this).apply {
            text = "Floating window aktif\n\nJendela ini tetap tampil di atas aplikasi lain. Sentuhan di luar area jendela diteruskan ke aplikasi di belakangnya.\n\nVersi awal • hyperGame X"
            textSize = 15f
            setTextColor(AndroidColor.WHITE)
            setPadding(8, 12, 8, 18)
        }
        val footer = TextView(this).apply {
            text = "Tarik header untuk memindahkan"
            textSize = 11f
            setTextColor(AndroidColor.LTGRAY)
            gravity = Gravity.END
            setPadding(8, 10, 8, 8)
            setOnTouchListener(ResizeTouchListener())
        }
        root.addView(header)
        root.addView(body)
        root.addView(footer)

        params = WindowManager.LayoutParams(
            300, 230,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 28
            y = 140
        }

        window = root
        windowManager.addView(root, params)
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    window?.let { windowManager.updateViewLayout(it, params) }
                    return true
                }
            }
            return true
        }
    }

    private inner class ResizeTouchListener : View.OnTouchListener {
        private var startW = 0
        private var startH = 0
        private var touchX = 0f
        private var touchY = 0f

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startW = params.width
                    startH = params.height
                    touchX = event.rawX
                    touchY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.width = (startW + event.rawX - touchX).toInt().coerceIn(240, 900)
                    params.height = (startH + event.rawY - touchY).toInt().coerceIn(180, 1200)
                    window?.let { windowManager.updateViewLayout(it, params) }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
            }
            return true
        }
    }

    override fun onDestroy() {
        window?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        window = null
        super.onDestroy()
    }
}
