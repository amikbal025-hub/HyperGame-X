# hyperGame X — Android starter

Native Kotlin + Jetpack Compose starter for Android 8.0+.

## Included in this first build
- Dark minimal home dashboard
- Built-in Tap Rush mini game
- Basic resizable/movable application overlay window
- Shizuku connection/permission status bridge
- Installed-app launcher list

## Important limitations
The floating panel is a real Android application overlay. It is not yet a full freeform host for arbitrary third-party apps. A normal app cannot embed another app's entire UI inside its own window. Launching another app as a true resizable freeform window depends on firmware support and system window-management policy. Shizuku provides shell/root-identity API access but does not itself enable freeform mode.

The overlay is interactive inside its own bounds. Touches outside the window can reach the app behind it. It cannot simultaneously receive a touch and pass that same touch through to the game underneath.

## Build
Open this folder as an Android Gradle project in Android Studio, or upload it to GitHub and add a workflow that runs `gradle :app:assembleDebug`.

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Shizuku
Install and start Shizuku separately. On Android 11+, wireless debugging can start its service without a computer. Shizuku usually needs to be started again after reboot on non-rooted devices. See the official developer guide: https://github.com/RikkaApps/Shizuku-API

## Device target
Minimum Android 8.0 (API 26). Actual freeform support varies by device and manufacturer.
